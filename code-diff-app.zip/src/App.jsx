
import React, { useState, useRef } from "react";
import { DiffEditor } from "@monaco-editor/react";

const languageMap = {
  js: "javascript",
  jsx: "javascript",
  ts: "typescript",
  java: "java",
  py: "python",
  json: "json",
  xml: "xml",
  html: "html",
  css: "css",
  yml: "yaml",
  yaml: "yaml",
  md: "markdown",
  sql: "sql",
};

export default function App() {
  const [fileA, setFileA] = useState("");
  const [fileB, setFileB] = useState("");
  const [fileAName, setFileAName] = useState("fileA.txt");
  const [fileBName, setFileBName] = useState("fileB.txt");
  const [language, setLanguage] = useState("plaintext");

  const originalEditorRef = useRef(null);
  const modifiedEditorRef = useRef(null);

  const detectLanguage = (filename) => {
    const ext = filename.split(".").pop().toLowerCase();
    return languageMap[ext] || "plaintext";
  };

  const handleFile = (file, setter, nameSetter) => {
    const reader = new FileReader();
    reader.onload = (e) => setter(e.target.result);
    reader.readAsText(file);
    nameSetter(file.name);
    setLanguage(detectLanguage(file.name));
  };

  const handleMount = (editor) => {
    originalEditorRef.current = editor.getOriginalEditor();
    modifiedEditorRef.current = editor.getModifiedEditor();
  };

  const saveMergedFile = () => {
    const content = modifiedEditorRef.current.getValue();
    const blob = new Blob([content], { type: "text/plain" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "merged-file.txt";
    a.click();
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>VS Code Style Diff Tool</h2>

      <input type="file" onChange={(e)=>handleFile(e.target.files[0],setFileA,setFileAName)} />
      <input type="file" onChange={(e)=>handleFile(e.target.files[0],setFileB,setFileBName)} />

      <button onClick={saveMergedFile}>Save Merged File</button>

      {fileA && fileB && (
        <DiffEditor
          height="500px"
          original={fileA}
          modified={fileB}
          language={language}
          theme="vs-dark"
          onMount={handleMount}
        />
      )}
    </div>
  );
}
